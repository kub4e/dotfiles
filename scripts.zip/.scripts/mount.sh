#! /bin/bash

USB=$1

mount -o gid=users,fmask=113,dmask=002 /dev/$USB /home/kub4e/mounts/defaults 
