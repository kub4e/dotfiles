#! /bin/bash
WM=$1

if [ "$WM" == "" ]
then
	startx
fi

if [ "$WM" == "dwm2" ]
then
	sed -i '$ d' ~/.xinitrc
	cat ~/.scripts/loop >> ~/.xinitrc
	startx
else
	sed -i '$ d' ~/.xinitrc
	echo exec $WM >> ~/.xinitrc
	startx
fi
